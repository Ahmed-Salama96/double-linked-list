#include<iostream>
using namespace std;
struct Data{

		int id ;
		string fn,ln;
		float gpa;
};
typedef struct Node
	{
		Data data;
		Node *next,*prev;
	} node;
class LinkList{
private:
	node* head;// global
public:
LinkList()
{
    head=NULL;
}
	node* create(int i,float g,string name1,string name2 )
	{
	  node* p=new Node();
	if(!p){
            cout<<"cannot create new node "<<endl;
		return 0;
	}
	else {
		p->data.id=i;
		p->data.gpa=g;
		p->data.fn=name1;
		p->data.ln=name2;
		p->next=p->prev=NULL;
	}
	return p;
	}
	void destroy(void)
	{
	    head=NULL;
	    cout<<"your list is deleted !"<<endl;
	}
	void print_list()
	{
	    node* temp;
	    temp=head;
	    if(temp==NULL){
            cout<<"nothing to print ... the list is empty "<<endl;
            return;
	}
	    while(temp)
        {
            PrintInfo(temp);
            temp=temp->next;
        }
	}
	void PrintInfo(node* n)
	{
	   if(n==NULL)
       {
           cout<<"sorry your list is empty ";
           return ;
       }
	    cout<<n->data.fn<<""<<n->data.ln<<" , "<<n->data.id<<" , "<<n->data.gpa<<"  ."<<endl;
	}
	int insertOreder(int i,float g,string name1,string name2)
	{
	    node* temp;
	    temp=head;
	    if(temp==NULL)
        {
            node*n =create(i,g,name1,name2);
         n->prev=head;
          head=n;
           return 1;
        }
        else
        {
            if(temp->next==NULL&&temp->data.id<i)
            {
                node* n=create(i,g,name1,name2);
                n->prev=temp;
                temp->next=n;
                return 1;
            }
            if(temp->next==NULL&&temp->data.id>i)
            {
                if(i==temp->data.id)
                {
                    cout<<"this student already in the list make sure and enter again"<<endl;
                    return 0;
                }
                node* n=create(i,g,name1,name2);
                n->next=temp;
                n->prev=head;
                temp->prev=n;
                head=n;
                return 1;
            }
            while(temp->data.id<i&&temp->next!=NULL)
            {temp=temp->next;}
            if(temp->data.id>i)
            {
                 node* n=create(i,g,name1,name2);
                  n->next=temp;
                 n->prev=temp->prev;
                 temp->prev->next=n;

                return 1;
            }
           else  if(i==temp->data.id)
                {
                    cout<<"this student already in the list make sure and enter again"<<endl;
                    return 0;
                }
                else{
                node* n=create(i,g,name1,name2);
                 n->prev=temp;
                temp->next=n;
        return 1;}
    }
        }
	int Delete_by_id(int i)
	{
	    node* temp;
	    temp=head;
	     if(temp==NULL)
       {
           cout<<"you cannot delete because the list is empty"<<endl;
           return 0;
       }
        while(temp)
        {
            if(temp->data.id==i)
            {
                temp->prev->next=temp->next;
                temp->next->prev=temp->prev;
                delete(temp);
                return 1;
                            }
            else
                temp=temp->next;
        }
       if(temp==NULL)
       {
           cout<<"error! this id is not here...."<<endl;
           return 0;
       }
	}
	int search_by_id(int i)
	{
	    node* temp;
	    temp=head;
	    while(temp)
        {
            if(temp->data.id==i)
            {
                cout<<" founded ^_^ ,  and his information is "<<endl;
                PrintInfo(temp);
                return 1;
            }
            else
                temp=temp->next;
        }
        return 0;
	}
	int sum()
	{
	    int c=0;
	    node* temp;
	    temp=head;
	    while(temp)
        {
            c++;
            temp=temp->next;
        }
        return c;
	}

};
int main(){
    LinkList l;
    int i=0;
    float g=0.0;
    string name1,name2;
    int choise;
    cout<<"welcome my professor to the class program"<<endl;
    cout<<" my program make you easily know everything  about your students "<<endl;

    while(1)
    {
        cout<<"\n\n";
        cout<<"press 1 to add student in the list "<<endl;
        cout<<"press 2 to remove student from the list"<<endl;
        cout<<"press 3 to search for student "<<endl;
        cout<<"press 4 to print all students "<<endl;
        cout<<"press 5 to print the info of a student "<<endl;
          cout<<"press 6 to get the number of students "<<endl;
           cout<<"press 7 to delete this list "<<endl;
         cout<<"press 8 to exist the program "<<endl;
        cin>>choise;
        switch(choise)
        {
        case 1:
            cout<<"please enter student's first name, last name , id and GPA  : ";
            cin>>name1>>name2>>i>>g;
          l.insertOreder(i,g,name1,name2);
            break;
        case 2:
            cout<<"enter the id of student you want to delete ";
            cin>>i;
            l.Delete_by_id(i);
            break;
        case 3:
            cout<<"enter the ID of student you need ";
            cin>>i;
            l.search_by_id(i);
            break;
        case 4:
            l.print_list();
            break;
        case 5:
            cout<<"enter student id to show his information ";
             cin>>i;
             l.search_by_id(i);
            break;

            break;
        case 6:
             cout<<"the number of students if "<<l.sum()<<endl;
            break;
        case 7:
            l.destroy();
       case 8:
             return 0;
             break;
       default:
        cout<<"this is wrong answer , try again!  "<<endl;
}}
return 0;
}
